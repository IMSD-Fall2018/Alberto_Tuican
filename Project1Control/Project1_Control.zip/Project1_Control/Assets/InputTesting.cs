﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputTesting : MonoBehaviour {
	public Emitter emitter_script;
	
	// Update is called once per frame
	

	void Update () {
		for (int x = 0; x < 50; x++) {
			for (int y = 0; y < 50; y++) {
			//Instantiate(, new Vector3(x - 0, y - 1), Quaternion.identity);
			//emitter_script.SpawnObject(new Vector3(x - 0, y - 1));//this.transform.position);
			emitter_script.SpawnObject(this.transform.position);
			}
		}
		// if (Input.GetKeyDown("space")) {
		// 	//Debug.Log("Input is working!");
		// 	emitter_script.SpawnObject(this.transform.position);
		// }
	}
	
}