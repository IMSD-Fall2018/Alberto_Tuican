﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickToMove : MonoBehaviour {
	public Camera cam;
	
	public GameObject player;
	

	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 screenPosition =  Vector3.zero;

		if (Input.GetMouseButton(0)) {
			screenPosition.x = Input.mousePosition.x;
			screenPosition.y = Input.mousePosition.y;
			screenPosition.z = -cam.transform.position.z;
			
			//Debug.Log(Camera.main.ScreenToWorldPoint(screenPosition));
			
			player.transform.position = cam.ScreenToWorldPoint(screenPosition);
			Debug.Log(player.transform.position);
		}
	}
}