﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {

	Vector3 newPosition = Vector3.zero;

	// Use this for initialization
	void Start () {
		newPosition = this.transform.position;
	}
	
	// Update is called once per frame
	void Update () {		
		newPosition.x += (Input.GetAxis("Horizontal") * 2 * Time.deltaTime);
		newPosition.x = Mathf.Clamp(newPosition.x, 0.075f, 2.65f);
		
		// if (Input.GetKey(KeyCode.Space)){
		// 	newPosition.y =  * 2 * Time.deltaTime);
		
		this.transform.position = newPosition;
	}
}
