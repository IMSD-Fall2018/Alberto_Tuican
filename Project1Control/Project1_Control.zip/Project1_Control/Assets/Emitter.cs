﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Emitter : MonoBehaviour {

	public GameObject spawn;
	public Emitter emitter_script;

	public float initialDelay = 0;
	public float repeatRate = 1f;
	int numberSpawned = 0;
	int count = 0;

	public Vector3 spawnPosition;
	public Vector3 spawnOffset;
	public Vector3 childOffset;

	public float y = 0.58f;
	public float z = -1;


	public void start() {
		InvokeRepeating("SpawnObject", initialDelay, repeatRate);
	}

	public void SpawnObject(Vector3 spawnPosition) {
		if (numberSpawned < 10) {
			spawnOffset = new Vector3(Random.Range(0.075f, 2.5f), y, z);
			spawnPosition = this.transform.position + spawnOffset;

			GameObject child = Instantiate(spawn, spawnPosition, Quaternion.identity);

			child.name = "Truck" + numberSpawned;

			numberSpawned++;

			if (numberSpawned > 1) {
			child.transform.position = new Vector3(Random.Range(0.075f, 2.5f), 0.58f - count, -1);
			count++;
			}
			

		// // }
		// for (int numberSpawned = 0; numberSpawned < 5; numberSpawned++) {
		// 	spawnOffset = new Vector3(Random.Range(0.075f, 2.5f), y, z);
		// 	spawnPosition = this.transform.position + spawnOffset;

		// 	GameObject child = Instantiate(spawn, spawnPosition, Quaternion.identity);

		// 	child.name = "Truck" + numberSpawned;

		// 	//for (int count = 0; count < 5; count++) {
		// 	child.transform.position = new Vector3(Random.Range(0.075f, 2.5f), 0.58f - count, -1); 
		// 	//}
		}
	}
}