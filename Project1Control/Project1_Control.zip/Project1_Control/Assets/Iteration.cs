﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Iteration : MonoBehaviour {

	// public GameObject go;

	// void Start () {
	// 	for(int i = 0; i < 10; i++) {
	// 		for(int j = 0; j < 10; j++) {
	// 			Instantiate(go, new Vector3(i - 5, j -, 0), Quaternion.identity);
	// 		}
	// 	}
	// }	

	public GameObject[] gos;

	void Start() {
		for(int i = 0; i < gos.Length; i++) {
			Instantiate(gos[i], new Vector3(i - 2, 0, 0), Quaternion.identity);
		}
	}
}